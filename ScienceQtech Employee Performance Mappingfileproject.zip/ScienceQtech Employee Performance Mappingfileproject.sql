/* 1.Create a database named employee, then import data_science_team.csv proj_table.csv and 
emp_record_table.csv into the employee database from the given resources. */
CREATE DATABASE employee;
USE employee;

/* Q.3	Write a query to fetch EMP_ID, FIRST_NAME, LAST_NAME, GENDER, and DEPARTMENT from the employee record table, 
and make a list of employees and details of their department. */ 
 SELECT EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT 
FROM emp_record_table;

 /* Q.4 Write a query to fetch EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPARTMENT, and EMP_RATING if the EMP_RATING is: 
●	less than two
●	greater than four 
●	between two and four */
-- Less than 2
SELECT EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT, EMP_RATING 
FROM emp_record_table 
WHERE EMP_RATING < 2;

-- Greater than 4
SELECT EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT, EMP_RATING 
FROM emp_record_table 
WHERE EMP_RATING > 4;

-- Between 2 and 4
SELECT EMP_ID, FIRST_NAME, LAST_NAME, GENDER, DEPT, EMP_RATING 
FROM emp_record_table 
WHERE EMP_RATING BETWEEN 2 AND 4;

 /*Q.5 Write a query to concatenate the FIRST_NAME and the LAST_NAME of employees in the Finance department from the employee table 
  and then give the resultant column alias as NAME.*/
SELECT CONCAT(FIRST_NAME, ' ', LAST_NAME) AS NAME 
FROM emp_record_table 
WHERE DEPT = 'Finance';

/* Q.6 Write a query to list only those employees who have someone reporting to them. Also, 
show the number of reporters (including the President). */
SELECT MANAGER_ID, COUNT(*) AS NUM_REPORTERS
FROM emp_record_table
WHERE MANAGER_ID IS NOT NULL
GROUP BY MANAGER_ID;

 /*Q.7 Write a query to list down all the employees from the healthcare and finance departments using union.
 Take data from the employee record table. */ 
 SELECT * FROM emp_record_table WHERE DEPT = 'Healthcare'
UNION
SELECT * FROM emp_record_table WHERE DEPT = 'Finance';

/* Q.8 Write a query to list down employee details such as EMP_ID, FIRST_NAME, LAST_NAME, ROLE, DEPARTMENT, and EMP_RATING grouped by dept. 
Also include the respective employee rating along with the max emp rating for the department. */
SELECT EMP_ID, FIRST_NAME, LAST_NAME, ROLE, DEPT, EMP_RATING,
       MAX(EMP_RATING) OVER (PARTITION BY DEPT) AS MAX_DEPT_RATING
FROM emp_record_table;

/*Q.9 Write a query to calculate the minimum and the maximum salary of the employees in each role. 
Take data from the employee record table. */
SELECT ROLE, MIN(SALARY) AS MIN_SALARY, MAX(SALARY) AS MAX_SALARY
FROM emp_record_table
GROUP BY ROLE;

 /* Q.10 Write a query to assign ranks to each employee based on their experience. 
 Take data from the employee record table. */
 SELECT EMP_ID, FIRST_NAME, LAST_NAME, EXP,
       RANK() OVER (ORDER BY EXP DESC) AS EXP_RANK
FROM emp_record_table;

 /* Q.11 Write a query to create a view that displays employees in various countries whose salary is more than six thousand. 
 Take data from the employee record table. */
 CREATE VIEW High_Salary_Employees AS
SELECT * FROM emp_record_table WHERE SALARY > 6000;

-- Now fetch the result
SELECT * FROM emp_record_table;


/* Q.12 Write a nested query to find employees with experience of more than ten years. 
Take data from the employee record table. */
SELECT * 
FROM emp_record_table 
WHERE EMP_ID IN (
    SELECT EMP_ID FROM emp_record_table WHERE EXP > 10);
    
/* Q.13 Write a query to create a stored procedure to retrieve the details of the employees whose experience is more than three years. 
Take data from the employee record table. */
DELIMITER //

CREATE PROCEDURE GetExperiencedEmployees()
BEGIN
    SELECT * 
    FROM emp_record_table 
    WHERE EXP > 3;
END //

DELIMITER ;
CALL GetExperiencedEmployees();



/*  Q.14. Stored function to check role consistency (Data Science Team) */
-- First, create a function to return expected role
DELIMITER //

CREATE FUNCTION GetExpectedRole(exp INT) 
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE expected_role VARCHAR(50);

    IF exp <= 2 THEN
        SET expected_role = 'JUNIOR DATA SCIENTIST';
    ELSEIF exp > 2 AND exp <= 5 THEN
        SET expected_role = 'ASSOCIATE DATA SCIENTIST';
    ELSEIF exp > 5 AND exp <= 10 THEN
        SET expected_role = 'SENIOR DATA SCIENTIST';
    ELSEIF exp > 10 AND exp <= 12 THEN
        SET expected_role = 'LEAD DATA SCIENTIST';
    ELSEIF exp > 12 AND exp <= 16 THEN
        SET expected_role = 'MANAGER';
    ELSE
        SET expected_role = 'UNKNOWN';
    END IF;

    RETURN expected_role;
END //

DELIMITER ;

SELECT EMP_ID, FIRST_NAME, LAST_NAME, EXP, ROLE,
       GetExpectedRole(EXP) AS Expected_Role,
       CASE 
           WHEN ROLE = GetExpectedRole(EXP) THEN 'MATCH'
           ELSE 'MISMATCH'
       END AS Role_Match_Status 
FROM Data_science_team;

/* Q.15.	Create an index to improve the cost and performance of the query to find the employee whose
 FIRST_NAME is ‘Eric’ in the employee table after checking the execution plan.*/
 SELECT *, 
       GetExpectedRole(EXP) AS Expected_Role,
       CASE 
           WHEN ROLE = GetExpectedRole(EXP) THEN 'MATCH'
           ELSE 'MISMATCH'
       END AS Role_Match_Status
FROM Data_science_team;

/* Q.16.	Write a query to calculate the bonus for all the employees, based on their ratings 
and salaries (Use the formula: 5% of salary * employee rating). */
SELECT EMP_ID, FIRST_NAME, LAST_NAME, SALARY, EMP_RATING,
       (0.05 * SALARY * EMP_RATING) AS BONUS
FROM emp_record_table;

/* Q.17.	Write a query to calculate the average salary distribution based on the continent and country. 
Take data from the employee record table. */
SELECT CONTINENT, COUNTRY, 
       AVG(SALARY) AS Average_Salary
FROM emp_record_table
GROUP BY CONTINENT, COUNTRY;










